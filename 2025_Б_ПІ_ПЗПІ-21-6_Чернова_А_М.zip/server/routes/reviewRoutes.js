const express = require("express");
const router = express.Router();
const reviewController = require("../controllers/reviewController");
const authMiddleware = require("../middleware/authMiddleware");
const reviewValidationMiddleware = require("../middleware/reviewValidationMiddleware");

// Публічні маршрути (доступ без авторизації)

// Отримати всі відгуки за типом та ID цілі (наприклад, лікар або заклад)
router.get("/target/:target_type/:target_id", reviewController.getByTarget);

// Отримати всі відгуки
router.get("/", reviewController.getAll);

// Отримати один відгук за його ID
router.get("/:id", reviewController.getById);

// Захищені маршрути (вимагають авторизацію)

// Створити новий відгук з перевіркою валідності
router.post(
  "/",
  authMiddleware,
  reviewValidationMiddleware,
  reviewController.create
);

// Оновити відгук
router.put("/:id", authMiddleware, reviewController.update);

// Видалити відгук
router.delete("/:id", authMiddleware, reviewController.delete);

module.exports = router;

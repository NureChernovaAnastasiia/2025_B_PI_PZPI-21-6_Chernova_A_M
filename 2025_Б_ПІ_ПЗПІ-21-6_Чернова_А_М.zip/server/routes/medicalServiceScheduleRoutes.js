const router = require("express").Router();
const medicalServiceScheduleController = require("../controllers/medicalServiceScheduleController");
const authMiddleware = require("../middleware/authMiddleware");
const roleMiddleware = require("../middleware/checkRoleMiddleware");

// Усі маршрути вимагають авторизації
router.use(authMiddleware);

// Бронювання медичної послуги (усі авторизовані користувачі)
router.post("/book", medicalServiceScheduleController.bookMedicalService);

// Отримати розклад послуги за ID послуги та датою (доступ: Admin, Doctor, Patient)
router.get(
  "/service/:medicalServiceId/date/:date",
  roleMiddleware("Admin", "Doctor", "Patient"),
  medicalServiceScheduleController.getByServiceAndDate
);

// Отримати розклад за лікарнею (доступ: Admin, Doctor)
router.get(
  "/by-hospital/:hospitalId",
  roleMiddleware("Admin", "Doctor"),
  medicalServiceScheduleController.getByHospital
);

// Отримати години роботи за ID послуги та датою (усі авторизовані)
router.get(
  "/working-hours/medical/:hospital_medical_service_id/:date",
  medicalServiceScheduleController.getWorkingHoursByDate
);

// Отримати всі записи розкладу (доступ: Admin, Doctor, Patient)
router.get(
  "/",
  roleMiddleware("Admin", "Doctor", "Patient"),
  medicalServiceScheduleController.getAll
);

// Отримати конкретний запис розкладу за ID (доступ: Admin, Doctor, Patient)
router.get(
  "/:id",
  roleMiddleware("Admin", "Doctor", "Patient"),
  medicalServiceScheduleController.getById
);

// Створення нового запису розкладу (доступ: Admin, Doctor)
router.post(
  "/",
  roleMiddleware("Admin", "Doctor"),
  medicalServiceScheduleController.create
);

// Оновлення запису розкладу (доступ: Admin, Doctor)
router.put(
  "/:id",
  roleMiddleware("Admin", "Doctor"),
  medicalServiceScheduleController.update
);

// Видалення запису розкладу (доступ: Admin, Doctor)
router.delete(
  "/:id",
  roleMiddleware("Admin", "Doctor"),
  medicalServiceScheduleController.delete
);

module.exports = router;

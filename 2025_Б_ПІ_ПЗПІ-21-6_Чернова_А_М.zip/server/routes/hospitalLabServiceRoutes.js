const Router = require("express");
const router = new Router();
const hospitalLabServiceController = require("../controllers/hospitalLabServiceController");
const authMiddleware = require("../middleware/authMiddleware");

// Отримати всі доступні лабораторні послуги для конкретного закладу
router.get(
  "/available/:hospitalId",
  hospitalLabServiceController.getAvailableForHospital
);

// Отримати всі записи про лабораторні послуги в лікарнях
router.get("/", hospitalLabServiceController.getAll);

// Отримати одну лабораторну послугу за її ID
router.get("/:id", hospitalLabServiceController.getById);

// Отримати всі лабораторні послуги, прив’язані до конкретного закладу
router.get("/hospital/:hospitalId", hospitalLabServiceController.getByHospital);

// Створити новий запис лабораторної послуги (авторизація обов’язкова)
router.post("/", authMiddleware, hospitalLabServiceController.create);

// Оновити існуючий запис лабораторної послуги (авторизація обов’язкова)
router.put("/:id", authMiddleware, hospitalLabServiceController.update);

// Видалити запис лабораторної послуги (авторизація обов’язкова)
router.delete("/:id", authMiddleware, hospitalLabServiceController.delete);

module.exports = router;

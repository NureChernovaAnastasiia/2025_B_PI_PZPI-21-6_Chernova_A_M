const express = require("express");
const router = express.Router();
const medicalServiceController = require("../controllers/medicalServiceController");
const authMiddleware = require("../middleware/authMiddleware");
const roleMiddleware = require("../middleware/checkRoleMiddleware");

// Усі маршрути вимагають авторизації
router.use(authMiddleware);

// Отримати медичні послуги, призначені певним лікарем (доступ: Admin, Doctor)
router.get(
  "/by-doctor/:doctorId",
  roleMiddleware("Admin", "Doctor"),
  medicalServiceController.getByDoctor
);

// Отримати медичні послуги, пов’язані з конкретним медичним закладом (доступ: Admin, Doctor)
router.get(
  "/hospital/:hospitalId",
  roleMiddleware("Admin", "Doctor"),
  medicalServiceController.getByHospital
);

// Позначити послугу як виконану (доступ: Admin, Doctor)
router.patch(
  "/mark-ready/:id",
  roleMiddleware("Admin", "Doctor"),
  medicalServiceController.markReadyStatus
);

// Завантажити медичний звіт у PDF (доступ: Admin, Doctor, Patient)
router.get(
  "/:id/pdf",
  roleMiddleware("Admin", "Doctor", "Patient"),
  medicalServiceController.downloadPDF
);

// Отримати всі послуги, пов’язані з пацієнтом
router.get("/patient/:patientId", medicalServiceController.getByPatient);

// Отримати медичну послугу за її ID
router.get("/:id", medicalServiceController.getById);

// Отримати всі медичні послуги (доступ: Admin, Doctor)
router.get(
  "/",
  roleMiddleware("Admin", "Doctor"),
  medicalServiceController.getAll
);

// Створити нову медичну послугу (доступ: Admin, Doctor)
router.post(
  "/",
  roleMiddleware("Admin", "Doctor"),
  medicalServiceController.create
);

// Оновити існуючу медичну послугу (доступ: Admin, Doctor)
router.put(
  "/:id",
  roleMiddleware("Admin", "Doctor"),
  medicalServiceController.update
);

// Видалити медичну послугу (доступ: лише Admin)
router.delete("/:id", roleMiddleware("Admin"), medicalServiceController.delete);

module.exports = router;

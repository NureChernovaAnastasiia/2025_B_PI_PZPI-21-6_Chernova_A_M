const express = require("express");
const router = express.Router();
const labTestController = require("../controllers/labTestController");
const authMiddleware = require("../middleware/authMiddleware");
const roleMiddleware = require("../middleware/checkRoleMiddleware");

// Усі маршрути вимагають авторизації
router.use(authMiddleware);

// Отримати тести за ID лікарні (доступ мають лише Admin та Doctor)
router.get(
  "/by-hospital/:hospitalId",
  roleMiddleware("Admin", "Doctor"),
  labTestController.getByHospital
);

// Позначити тест як готовий (Admin, Doctor)
router.patch(
  "/mark-ready/:id",
  roleMiddleware("Admin", "Doctor"),
  labTestController.markReadyStatus
);

// Отримати тести за ID лікаря
router.get("/doctor/:doctorId", labTestController.getByDoctor);

// Отримати всі лабораторні тести
router.get("/", labTestController.getAll);

// Отримати тест за ID
router.get("/:id", labTestController.getById);

// Отримати тести за ID пацієнта
router.get("/patient/:patientId", labTestController.getByPatient);

// Отримати тести пацієнта за статусом
router.get("/status/filter", labTestController.getByPatientStatus);

// Створити новий лабораторний тест
router.post("/", labTestController.create);

// Оновити лабораторний тест
router.put("/:id", labTestController.update);

// Видалити лабораторний тест
router.delete("/:id", labTestController.delete);

// Завантажити PDF-версію тесту
router.get("/:id/pdf", labTestController.downloadPDF);

module.exports = router;

const router = require("express").Router();
const hospitalMedicalServiceController = require("../controllers/hospitalMedicalServiceController");
const authMiddleware = require("../middleware/authMiddleware");
const roleMiddleware = require("../middleware/checkRoleMiddleware");

// Усі маршрути вимагають авторизації
router.use(authMiddleware);

// Отримати послуги, доступні в конкретному закладі
router.get(
  "/available/:hospitalId",
  hospitalMedicalServiceController.getAvailableForHospital
);

// Отримати всі послуги, прив’язані до певного закладу
router.get(
  "/hospital/:hospitalId",
  hospitalMedicalServiceController.getByHospital
);

// Отримати послуги, які надає певний лікар
router.get("/doctor/:doctorId", hospitalMedicalServiceController.getByDoctor);

// Отримати одну медичну послугу за ID
router.get("/:id", hospitalMedicalServiceController.getById);

// Отримати всі медичні послуги (доступно для ролей Admin, Doctor, Patient)
router.get(
  "/",
  roleMiddleware("Admin", "Doctor", "Patient"),
  hospitalMedicalServiceController.getAll
);

// Створити нову послугу (доступно для Admin і Doctor)
router.post(
  "/",
  roleMiddleware("Admin", "Doctor"),
  hospitalMedicalServiceController.create
);

// Оновити існуючу послугу (доступно для Admin і Doctor)
router.put(
  "/:id",
  roleMiddleware("Admin", "Doctor"),
  hospitalMedicalServiceController.update
);

// Видалити послугу (доступно для Admin і Doctor)
router.delete(
  "/:id",
  roleMiddleware("Admin", "Doctor"),
  hospitalMedicalServiceController.delete
);

module.exports = router;

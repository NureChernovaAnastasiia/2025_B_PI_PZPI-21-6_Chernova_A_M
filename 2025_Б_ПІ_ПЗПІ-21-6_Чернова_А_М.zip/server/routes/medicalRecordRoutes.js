const express = require("express");
const router = express.Router();
const medicalRecordController = require("../controllers/medicalRecordController");
const authMiddleware = require("../middleware/authMiddleware");
const roleMiddleware = require("../middleware/checkRoleMiddleware");

// Усі маршрути вимагають авторизації
router.use(authMiddleware);

// Отримати призначення (рецепти) за ID медичної картки та пацієнта
router.get(
  "/:recordId/patient/:patientId/prescriptions",
  roleMiddleware("Admin", "Doctor", "Patient"),
  medicalRecordController.getPrescriptionsByRecordAndPatient
);

// Отримати всі медичні картки пацієнта
router.get(
  "/patient/:patientId",
  roleMiddleware("Admin", "Doctor", "Patient"),
  medicalRecordController.getRecordsByPatient
);

// Отримати всі записи медичних карток
router.get("/", medicalRecordController.getAll);

// Отримати один запис за ID
router.get("/:id", medicalRecordController.getById);

// Створити новий запис
router.post("/", medicalRecordController.create);

// Оновити існуючий запис
router.put("/:id", medicalRecordController.update);

// Видалити запис
router.delete("/:id", medicalRecordController.delete);

module.exports = router;

const express = require("express");
const router = express.Router();
const hospitalStaffController = require("../controllers/hospitalStaffController");
const authMiddleware = require("../middleware/authMiddleware");
const checkRoleMiddleware = require("../middleware/checkRoleMiddleware");

// Усі маршрути вимагають авторизації
router.use(authMiddleware);

// Отримати список унікальних посад серед медичного персоналу
router.get("/positions/unique", hospitalStaffController.getUniquePositions);

// Отримати інформацію про медичного працівника за userId
router.get("/by-user/:userId", hospitalStaffController.getByUserId);

// Отримати працівників лікарні, які не є лікарями
router.get(
  "/non-doctors/:hospitalId",
  hospitalStaffController.getNonDoctorsByHospital
);

// Отримати всіх лікарів
router.get("/doctors", hospitalStaffController.getDoctors);

// Отримати всіх працівників медичного персоналу
router.get("/medical-staff", hospitalStaffController.getMedicalStaff);

// Отримати одного працівника за його ID
router.get("/:id", hospitalStaffController.getById);

// Отримати список усіх працівників
router.get("/", hospitalStaffController.getAll);

// Нижче — маршрути лише для користувачів з роллю "Admin"

// Створити нового працівника
router.post("/", checkRoleMiddleware("Admin"), hospitalStaffController.create);

// Оновити дані працівника
router.put(
  "/:id",
  checkRoleMiddleware("Admin"),
  hospitalStaffController.update
);

// Видалити працівника
router.delete(
  "/:id",
  checkRoleMiddleware("Admin"),
  hospitalStaffController.delete
);

module.exports = router;

const Router = require("express");
const router = new Router();
const labTestInfoController = require("../controllers/labTestInfoController");
const authMiddleware = require("../middleware/authMiddleware");
const checkRoleMiddleware = require("../middleware/checkRoleMiddleware");

// Публічні маршрути (доступні без авторизації)

// Отримати всі лабораторні тести
router.get("/", labTestInfoController.getAll);

// Отримати тест за його ID
router.get("/:id", labTestInfoController.getById);

// Отримати тести, доступні у певній лікарні
router.get("/hospital/:hospitalId", labTestInfoController.getByHospital);

// Маршрути лише для адміністратора (вимагають авторизації та перевірки ролі)

// Створити новий лабораторний тест
router.post(
  "/",
  authMiddleware,
  checkRoleMiddleware("Admin"),
  labTestInfoController.create
);

// Оновити дані тесту
router.put(
  "/:id",
  authMiddleware,
  checkRoleMiddleware("Admin"),
  labTestInfoController.update
);

// Видалити тест
router.delete(
  "/:id",
  authMiddleware,
  checkRoleMiddleware("Admin"),
  labTestInfoController.delete
);

module.exports = router;

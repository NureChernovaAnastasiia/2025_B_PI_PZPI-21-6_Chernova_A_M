const express = require("express");
const router = express.Router();
const labTestScheduleController = require("../controllers/labTestScheduleController");
const authMiddleware = require("../middleware/authMiddleware");
const roleMiddleware = require("../middleware/checkRoleMiddleware");

// Усі маршрути вимагають авторизації
router.use(authMiddleware);

// Запис і оплата лабораторного тесту
router.post("/pay-and-book", labTestScheduleController.payAndBookLabTest);

// Отримати всі розклади лабораторних тестів для конкретної лікарні
router.get(
  "/by-hospital/:hospitalId",
  roleMiddleware("Admin", "Doctor"),
  labTestScheduleController.getByHospital
);

// Отримати розклад за ID послуги та датою
router.get(
  "/lab/:labServiceId/date/:date",
  roleMiddleware("Admin", "Doctor", "Patient"),
  labTestScheduleController.getByLabAndDate
);

// Отримати робочі години на вказану дату
router.get(
  "/working-hours/lab/:hospital_lab_service_id/:date",
  labTestScheduleController.getWorkingHoursByDate
);

// Отримати всі розклади
router.get(
  "/",
  roleMiddleware("Admin", "Doctor", "Patient"),
  labTestScheduleController.getAll
);

// Отримати розклад за ID
router.get(
  "/:id",
  roleMiddleware("Admin", "Doctor", "Patient"),
  labTestScheduleController.getById
);

// Створити новий розклад
router.post(
  "/",
  roleMiddleware("Admin", "Doctor"),
  labTestScheduleController.create
);

// Оновити розклад
router.put(
  "/:id",
  roleMiddleware("Admin", "Doctor"),
  labTestScheduleController.update
);

// Видалити розклад
router.delete(
  "/:id",
  roleMiddleware("Admin", "Doctor"),
  labTestScheduleController.delete
);

module.exports = router;

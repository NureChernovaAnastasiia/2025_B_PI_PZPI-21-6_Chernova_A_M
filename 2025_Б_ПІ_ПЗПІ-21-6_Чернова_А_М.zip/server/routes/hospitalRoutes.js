const express = require("express");
const router = express.Router();
const hospitalController = require("../controllers/hospitalController");
const authMiddleware = require("../middleware/authMiddleware");
const checkRole = require("../middleware/checkRoleMiddleware");

// Отримати унікальні назви лікарень
router.get("/unique-names", hospitalController.getUniqueNames);

// Публічні маршрути – доступні для всіх користувачів
router.get("/", hospitalController.getAll); // Отримати список усіх лікарень
router.get("/:id", hospitalController.getById); // Отримати лікарню за її ID

// Захищені маршрути – тільки для користувачів з роллю "Admin"
router.post("/", authMiddleware, checkRole("Admin"), hospitalController.create); // Створити нову лікарню

router.put(
  "/:id",
  authMiddleware,
  checkRole("Admin"),
  hospitalController.update
); // Оновити дані лікарні

router.delete(
  "/:id",
  authMiddleware,
  checkRole("Admin"),
  hospitalController.delete
); // Видалити лікарню

module.exports = router;

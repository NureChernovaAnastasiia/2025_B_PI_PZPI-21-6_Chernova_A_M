const express = require("express");
const router = express.Router();
const prescriptionController = require("../controllers/prescriptionController");
const authMiddleware = require("../middleware/authMiddleware");

// Усі маршрути вимагають авторизації
router.use(authMiddleware);

// Завантажити рецепт у форматі PDF
router.get("/:id/pdf", authMiddleware, prescriptionController.downloadPdf);

// Отримати конкретний рецепт пацієнта за його ID
router.get(
  "/patient/:patientId/:id",
  authMiddleware,
  prescriptionController.getByPatientAndId
);

// Отримати всі рецепти певного пацієнта
router.get("/patient/:patientId", prescriptionController.getByPatient);

// Отримати всі рецепти (для адміністратора або лікаря)
router.get("/", prescriptionController.getAll);

// Отримати один рецепт за його ID
router.get("/:id", prescriptionController.getById);

// Створити новий рецепт
router.post("/", prescriptionController.create);

// Оновити існуючий рецепт
router.put("/:id", prescriptionController.update);

// Видалити рецепт
router.delete("/:id", prescriptionController.delete);

module.exports = router;

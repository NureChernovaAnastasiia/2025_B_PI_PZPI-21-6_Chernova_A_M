const express = require("express");
const router = express.Router();
const controller = require("../controllers/medicalServiceInfoController");
const authMiddleware = require("../middleware/authMiddleware");
const roleMiddleware = require("../middleware/checkRoleMiddleware");

// Усі маршрути вимагають авторизації
router.use(authMiddleware);

// Отримати всі доступні медичні послуги
router.get("/", controller.getAll);

// Отримати інформацію про медичну послугу за її ID
router.get("/:id", controller.getById);

// Отримати список медичних послуг для конкретного медичного закладу
router.get("/hospital/:hospitalId", controller.getByHospital);

// Створити нову медичну послугу (тільки для адміністратора)
router.post("/", roleMiddleware("Admin"), controller.create);

// Оновити існуючу медичну послугу (тільки для адміністратора)
router.put("/:id", roleMiddleware("Admin"), controller.update);

// Видалити медичну послугу (тільки для адміністратора)
router.delete("/:id", roleMiddleware("Admin"), controller.delete);

module.exports = router;

const express = require("express");
const router = express.Router();
const doctorController = require("../controllers/doctorController");
const authMiddleware = require("../middleware/authMiddleware");
const checkRole = require("../middleware/checkRoleMiddleware");

// Авторизація для всіх маршрутів
router.use(authMiddleware);

// Оновлення фото лікаря
router.put("/:id/photo", authMiddleware, doctorController.updatePhoto);

// Отримати унікальні спеціалізації лікарів
router.get("/specializations", doctorController.getUniqueSpecializations);

// Отримати лікаря за userId (доступ лише для Admin або Doctor)
router.get(
  "/by-user/:userId",
  checkRole("Admin", "Doctor"),
  doctorController.getDoctorByUserId
);

// Отримати список всіх лікарів
router.get("/", authMiddleware, doctorController.getAll);

// Отримати лікаря за його ID
router.get("/:id", authMiddleware, doctorController.getById);

// Отримати лікарів певного закладу
router.get("/by-hospital/:hospitalId", doctorController.getByHospital);

// Створення нового лікаря (доступ лише для Admin)
router.post("/", authMiddleware, checkRole("Admin"), doctorController.create);

// Оновлення інформації про лікаря (доступ лише для Admin)
router.put("/:id", authMiddleware, checkRole("Admin"), doctorController.update);

// Видалення лікаря (доступ лише для Admin)
router.delete(
  "/:id",
  authMiddleware,
  checkRole("Admin"),
  doctorController.delete
);

module.exports = router;
